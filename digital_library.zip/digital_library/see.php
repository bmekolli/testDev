<?php
session_start();

if(isset($_POST['submit']))
{
    $title=$_POST['title'];
    $Description=$_POST['Description'];
    $rollno=$_SESSION['RollNo'];

$sql1="insert into recommendations (Book_Name,Description,RollNo) values ('$title','$Description','$rollno')"; 

echo $rollno;
    
}
?> 
